package com.gameassist.models

import android.graphics.Rect

/**
 * Represents a game object detected on screen.
 * Used by DetectionEngine, ObjectTracker, and DecisionEngine.
 */
data class GameObject(
    val type: ObjectType,
    val boundingBox: Rect,
    val centerX: Int,
    val centerY: Int,
    val width: Int,
    val height: Int,
    val confidence: Float = 1.0f,
    val trackedId: Int = -1  // Assigned by ObjectTracker
)

enum class ObjectType {
    METEOR,        // Orange/red fireballs - THREAT
    UFO,           // Blue satellite - THREAT (diagonal movement)
    PHONE,         // Purple glowing phones - COLLECTIBLE
    STAR,          // White star items - COLLECTIBLE
    PLAYER,        // Pink cape character - PLAYER POSITION
    UNKNOWN        // Unrecognized object
}

enum class ThreatPriority {
    CRITICAL,      // Will hit player in <500ms - dodge NOW
    HIGH,          // Will hit player in <1000ms
    MEDIUM,        // In path but far away
    LOW,           // Off to the side, low risk
    SAFE           // No threat
}

/**
 * Data class for UFO trajectory prediction.
 * Used by TrajectoryPredictor.
 */
data class Trajectory(
    val objectId: Int,
    val velocityX: Float,       // pixels per frame (horizontal)
    val velocityY: Float,       // pixels per frame (vertical)
    val predictedLandingX: Int, // Where it will be at player's Y level
    val confidence: Float,      // 0.0-1.0, based on how many frames tracked
    val willHitPlayer: Boolean   // Predicted landing X within player width
)

/**
 * Movement decision output from DecisionEngine.
 * Used by GestureController.
 */
data class MovementDecision(
    val targetX: Int,            // Target X coordinate to move to
    val priority: ThreatPriority,
    val reason: String,          // Why this decision was made
    val isCollecting: Boolean = false,  // True if moving toward collectible
    val urgencyMs: Long = 300     // How fast to move (lower = faster)
)
