package com.gameassist

import android.util.Log
import com.gameassist.models.GameObject
import com.gameassist.models.MovementDecision
import com.gameassist.models.ObjectType
import com.gameassist.models.ThreatPriority
import com.gameassist.models.Trajectory
import kotlin.math.abs

/**
 * Decision engine that analyzes detected threats and collectibles,
 * then outputs the optimal X position to move to.
 *
 * Implements all priority logic:
 * - Challenge 1: Strict priority queue (Threat > Collectible)
 * - Challenge 1: Jaan vs Coin intersection block (±15px margin)
 * - Challenge 2: UFO trajectory-based dodging
 * - Problem 6: Multi-meteor "Least Danger" algorithm
 * - Problem 7: Player dropout recovery
 */
class DecisionEngine(
    private val screenWidth: Int,
    private val screenHeight: Int
) {

    companion object {
        private const val TAG = "DecisionEngine"
        private const val THREAT_X_MARGIN = 50       // Danger zone width around threat X (pixels)
        private const val COLLECTIBLE_X_MARGIN = 15   // Intersection check margin (Challenge 1)
        private const val PLAYER_SAFE_MARGIN = 30     // Safe distance from screen edges
        private const val MOVE_URGENCY_FAST = 150L   // Fast dodge (ms)
        private const val MOVE_URGENCY_NORMAL = 250L // Normal move (ms)
        private const val PLAYER_Y_RATIO = 0.82f
    }

    private val playerY: Int = (screenHeight * PLAYER_Y_RATIO).toInt()

    // Player position memory (Problem 7: dropout recovery)
    private var lastKnownPlayerX: Int = screenWidth / 2
    private var lastKnownPlayerTime: Long = 0
    private var playerPositionLost: Boolean = false

    // Score tracking for adaptive scaling
    private var currentScore: Int = 0

    /**
     * Main decision method. Takes all detected objects and UFO trajectories,
     * returns the optimal movement decision.
     *
     * @param objects All detected game objects in current frame
     * @param ufoTrajectories Predicted UFO landing positions
     * @param currentFps Current processing FPS for time estimation
     * @return MovementDecision with target X, priority, and urgency
     */
    fun decide(
        objects: List<GameObject>,
        ufoTrajectories: Map<Int, Trajectory>,
        currentFps: Float
    ): MovementDecision {
        // Step 1: Find player position
        val playerX = findPlayerX(objects)
        updatePlayerMemory(playerX)

        // Step 2: Collect all threat zones on X axis
        val threatZones = calculateThreatZones(objects, ufoTrajectories, currentFps)

        // Step 3: If no threats, look for collectibles
        if (threatZones.isEmpty()) {
            val collectibleDecision = findBestCollectible(objects, playerX, emptyList())
            if (collectibleDecision != null) {
                return collectibleDecision
            }
            // Nothing to do - stay at current position
            return MovementDecision(
                targetX = playerX,
                priority = ThreatPriority.SAFE,
                reason = "No threats or collectibles nearby",
                urgencyMs = MOVE_URGENCY_NORMAL
            )
        }

        // Step 4: Find safest X position (away from all threat zones)
        val safeX = findSafestX(playerX, threatZones)

        // Step 5: Check if any collectible is safe to pick up
        // Challenge 1: Jaan vs Coin - only if collectible NOT in any threat zone
        val safeCollectible = findBestCollectible(objects, playerX, threatZones)
        if (safeCollectible != null && isSafeToCollect(safeCollectible.targetX, threatZones)) {
            // Collectible is safe AND we need to move anyway - combine!
            val threatDecision = MovementDecision(
                targetX = safeX,
                priority = determineThreatPriority(threatZones, playerX, currentFps),
                reason = "Collecting safe item while dodging",
                isCollecting = true,
                urgencyMs = MOVE_URGENCY_FAST
            )
            // If safe collectible is between us and safe zone, go for it
            if (isOnTheWay(playerX, safeCollectible.targetX, safeX)) {
                return safeCollectible.copy(
                    priority = threatDecision.priority
                )
            }
            return threatDecision
        }

        // Step 6: Pure dodge decision
        return MovementDecision(
            targetX = safeX,
            priority = determineThreatPriority(threatZones, playerX, currentFps),
            reason = buildThreatReason(threatZones),
            urgencyMs = MOVE_URGENCY_FAST
        )
    }

    /**
     * Find player X position from detected objects.
     * Falls back to last known position if player not found (Problem 7).
     */
    private fun findPlayerX(objects: List<GameObject>): Int {
        val player = objects.filter { it.type == ObjectType.PLAYER }

        return if (player.isNotEmpty()) {
            // Average X of all player detections (might detect multiple parts of character)
            val avgX = player.map { it.centerX }.average().toInt()
            playerPositionLost = false
            lastKnownPlayerX = avgX
            lastKnownPlayerTime = System.currentTimeMillis()
            Log.d(TAG, "Player found at X=$avgX")
            avgX
        } else {
            // Player not detected - use last known position
            playerPositionLost = true
            val timeSince = System.currentTimeMillis() - lastKnownPlayerTime
            Log.w(TAG, "Player NOT found! Using last known X=$lastKnownPlayerX (${timeSince}ms ago)")

            // After 500ms of no detection, drift toward center
            if (timeSince > 500) {
                val center = screenWidth / 2
                val blendFactor = minOf(1f, (timeSince - 500).toFloat() / 1000f)
                return (lastKnownPlayerX * (1 - blendFactor) + center * blendFactor).toInt()
            }

            lastKnownPlayerX
        }
    }

    private fun updatePlayerMemory(playerX: Int) {
        if (!playerPositionLost) {
            lastKnownPlayerX = playerX
            lastKnownPlayerTime = System.currentTimeMillis()
        }
    }

    /**
     * Calculate all X-axis danger zones from threats.
     * Challenge 2: UFO uses predicted landing X, not current X.
     */
    private fun calculateThreatZones(
        objects: List<GameObject>,
        ufoTrajectories: Map<Int, Trajectory>,
        currentFps: Float
    ): List<ThreatZone> {
        val zones = mutableListOf<ThreatZone>()

        // Process meteors - use their current X as landing prediction (mostly straight down)
        for (obj in objects.filter { it.type == ObjectType.METEOR }) {
            // Only consider meteors that are above player and falling
            if (obj.centerY < playerY) {
                zones.add(
                    ThreatZone(
                        centerX = obj.centerX,
                        halfWidth = THREAT_X_MARGIN,
                        type = ObjectType.METEOR,
                        urgency = calculateUrgency(obj.centerY, currentFps),
                        trackedId = obj.trackedId
                    )
                )
            }
        }

        // Process UFOs - use PREDICTED landing X (Challenge 2)
        for (obj in objects.filter { it.type == ObjectType.UFO }) {
            val trajectory = ufoTrajectories[obj.trackedId]
            if (trajectory != null && trajectory.confidence > 0.4f) {
                // Use predicted landing X
                zones.add(
                    ThreatZone(
                        centerX = trajectory.predictedLandingX,
                        halfWidth = THREAT_X_MARGIN + 10,  // UFO wider danger zone
                        type = ObjectType.UFO,
                        urgency = calculateUrgency(obj.centerY, currentFps),
                        trackedId = obj.trackedId
                    )
                )
                Log.d(TAG, "UFO #${obj.trackedId} danger zone at predicted X=${trajectory.predictedLandingX}")
            } else {
                // Not enough data for prediction, use current position with wider margin
                zones.add(
                    ThreatZone(
                        centerX = obj.centerX,
                        halfWidth = THREAT_X_MARGIN + 30,  // Extra wide when uncertain
                        type = ObjectType.UFO,
                        urgency = calculateUrgency(obj.centerY, currentFps),
                        trackedId = obj.trackedId
                    )
                )
            }
        }

        // Sort by urgency (most urgent first)
        return zones.sortedBy { it.urgency }
    }

    /**
     * Calculate urgency (time to impact) for a threat.
     * Lower value = more urgent.
     */
    private fun calculateUrgency(threatY: Int, fps: Float): Float {
        val distanceToPlayer = playerY - threatY
        return if (fps > 0) distanceToPlayer / fps else Float.MAX_VALUE
    }

    /**
     * Find the safest X position to dodge to.
     * Problem 6: Multi-meteor "Least Danger" algorithm.
     */
    private fun findSafestX(playerX: Int, threatZones: List<ThreatZone>): Int {
        // Strategy: Evaluate multiple candidate positions, pick safest one

        val candidates = mutableListOf<Int>()

        // Candidate 1: Current player position (if safe)
        candidates.add(playerX)

        // Candidate 2: Left edge safe zone
        candidates.add(PLAYER_SAFE_MARGIN)

        // Candidate 3: Right edge safe zone
        candidates.add(screenWidth - PLAYER_SAFE_MARGIN)

        // Candidate 4: Midpoints between threat zones
        for (i in 0 until threatZones.size - 1) {
            val midX = (threatZones[i].centerX + threatZones[i + 1].centerX) / 2
            candidates.add(midX)
        }

        // Candidate 5: 200px increments across screen
        for (x in PLAYER_SAFE_MARGIN..(screenWidth - PLAYER_SAFE_MARGIN) step 200) {
            candidates.add(x)
        }

        // Score each candidate
        var bestX = playerX
        var bestScore = Float.NEGATIVE_INFINITY

        for (candidate in candidates) {
            val score = evaluatePosition(candidate, threatZones, playerX)
            if (score > bestScore) {
                bestScore = score
                bestX = candidate
            }
        }

        Log.d(TAG, "Safest X=$bestX (score=${"%.1f".format(bestScore)}, from $playerX)")
        return bestX.coerceIn(PLAYER_SAFE_MARGIN, screenWidth - PLAYER_SAFE_MARGIN)
    }

    /**
     * Score a candidate X position. Higher = safer.
     */
    private fun evaluatePosition(
        x: Int,
        threatZones: List<ThreatZone>,
        playerX: Int
    ): Float {
        var score = 0f

        // Distance from each threat zone (closer = worse)
        for (zone in threatZones) {
            val dist = abs(x - zone.centerX)
            if (dist < zone.halfWidth) {
                // Inside danger zone - very bad
                score -= 1000f / (zone.halfWidth - dist + 1)
            } else {
                // Outside danger zone - distance is good
                score += dist.toFloat() / zone.halfWidth
            }

            // Bonus for urgency (prefer moving away from urgent threats)
            if (zone.urgency < 10) {  // Very urgent
                if (dist >= zone.halfWidth) score += 50f
            }
        }

        // Penalty for moving too far (unnecessary movement wastes time)
        val moveDistance = abs(x - playerX)
        if (moveDistance > screenWidth / 3) {
            score -= moveDistance * 0.1f
        }

        // Small penalty for being near edges
        if (x < PLAYER_SAFE_MARGIN * 2 || x > screenWidth - PLAYER_SAFE_MARGIN * 2) {
            score -= 20f
        }

        return score
    }

    /**
     * Challenge 1: Jaan vs Coin - check if collectible is safe to reach.
     * If collectible's X is within any threat zone (±15px), BLOCK it.
     */
    private fun isSafeToCollect(collectibleX: Int, threatZones: List<ThreatZone>): Boolean {
        for (zone in threatZones) {
            if (abs(collectibleX - zone.centerX) < zone.halfWidth + COLLECTIBLE_X_MARGIN) {
                Log.d(TAG, "Collectible at X=$collectibleX BLOCKED by threat at X=${zone.centerX}")
                return false
            }
        }
        return true
    }

    /**
     * Find the best collectible to go after.
     */
    private fun findBestCollectible(
        objects: List<GameObject>,
        playerX: Int,
        threatZones: List<ThreatZone>
    ): MovementDecision? {
        val collectibles = objects.filter {
            it.type == ObjectType.PHONE || it.type == ObjectType.STAR
        }.filter {
            // Only consider collectibles above player
            it.centerY < playerY
        }.filter {
            // Only consider if within reasonable horizontal distance
            abs(it.centerX - playerX) < screenWidth / 2
        }

        if (collectibles.isEmpty()) return null

        // Prefer phones (higher score) over stars, then nearest first
        val sorted = collectibles.sortedWith(
            compareByDescending<GameObject> {
                when (it.type) {
                    ObjectType.PHONE -> 2
                    ObjectType.STAR -> 1
                    else -> 0
                }
            }.thenBy { abs(it.centerX - playerX) }
        )

        val target = sorted.first()
        return MovementDecision(
            targetX = target.centerX,
            priority = ThreatPriority.LOW,
            reason = "Collecting ${target.type.name} at X=${target.centerX}",
            isCollecting = true,
            urgencyMs = MOVE_URGENCY_NORMAL
        )
    }

    private fun isOnTheWay(fromX: Int, viaX: Int, toX: Int): Boolean {
        return when {
            toX > fromX -> viaX in fromX..toX
            toX < fromX -> viaX in toX..fromX
            else -> false
        }
    }

    private fun determineThreatPriority(
        threatZones: List<ThreatZone>,
        playerX: Int,
        currentFps: Float
    ): ThreatPriority {
        if (threatZones.isEmpty()) return ThreatPriority.SAFE

        // Check if any threat zone includes current player position
        for (zone in threatZones) {
            if (abs(playerX - zone.centerX) < zone.halfWidth) {
                return when {
                    zone.urgency < 5 -> ThreatPriority.CRITICAL
                    zone.urgency < 15 -> ThreatPriority.HIGH
                    else -> ThreatPriority.MEDIUM
                }
            }
        }

        // Check closest threat distance
        val closestUrgency = threatZones.minOf { it.urgency }
        return when {
            closestUrgency < 10 -> ThreatPriority.HIGH
            closestUrgency < 25 -> ThreatPriority.MEDIUM
            else -> ThreatPriority.LOW
        }
    }

    private fun buildThreatReason(threatZones: List<ThreatZone>): String {
        val meteors = threatZones.count { it.type == ObjectType.METEOR }
        val ufos = threatZones.count { it.type == ObjectType.UFO }
        return buildString {
            if (meteors > 0) append("Dodging $meteors meteor${if (meteors > 1) "s" else ""}")
            if (meteors > 0 && ufos > 0) append(" + ")
            if (ufos > 0) append("Avoiding $ufos UFO${if (ufos > 1) "s" else ""}")
        }
    }

    /**
     * Update score for adaptive scaling.
     */
    fun updateScore(newScore: Int) {
        currentScore = newScore
    }

    fun getAdaptiveScanTopPercent(): Float {
        return when {
            currentScore < 5 -> 0.60f   // Early game: scan bottom 40%
            currentScore < 15 -> 0.45f  // Mid game: scan bottom 55%
            else -> 0.30f               // Late game: scan bottom 70%
        }
    }

    fun getPlayerX(): Int = lastKnownPlayerX

    fun reset() {
        lastKnownPlayerX = screenWidth / 2
        lastKnownPlayerTime = 0
        playerPositionLost = false
        currentScore = 0
    }

    private data class ThreatZone(
        val centerX: Int,
        val halfWidth: Int,
        val type: ObjectType,
        val urgency: Float,
        val trackedId: Int
    )
}
