package com.gameassist

import android.accessibilityservice.AccessibilityService
import android.app.Service
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import androidx.core.app.NotificationCompat
import com.gameassist.models.Trajectory
import kotlinx.coroutines.*
import java.nio.ByteBuffer

/**
 * Main GameAssist Accessibility Service.
 *
 * FIXED BUGS (v2):
 * - FIX #2: ImageReader uses DOWNSCALED resolution (not full screen) → saves ~12MB/frame
 * - FIX #3: displayMetrics properly stored and used
 * - FIX #4: ByteBuffer properly imported
 * - FIX #5: Removed conflicting listener, coroutine-only image acquisition
 * - FIX #13: scanStep is now mutable var in DetectionEngine
 * - FIX #14: foregroundServiceType specified for Android 14+
 * - FIX #16: Global crash handler prevents silent death
 * - FIX #17: No background subtraction dimension mismatch
 * - FIX #19: RAM monitor auto-shuts down if memory too low
 */
class GameAssistService : AccessibilityService() {

    companion object {
        private const val TAG = "GameAssistService"
        private const val CHANNEL_ID = "gameassist_channel"
        private const val FOREGROUND_NOTIFY_ID = 1002

        // DOWNSCALED capture resolution for 4GB RAM safety (was full screen = crash)
        private const val CAPTURE_WIDTH = 360
        private const val CAPTURE_HEIGHT = 800

        // RAM safety thresholds (in MB of free memory)
        private const val RAM_SHUTDOWN_MB = 80L    // Auto-shutdown if < 80MB free
        private const val RAM_WARNING_MB = 150L   // Heavy throttle if < 150MB free
    }

    // Screen dimensions
    private var screenWidth = 720
    private var screenHeight = 1280
    private var densityDpi = 320

    // MediaProjection + ImageReader
    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    // Core components
    private var detectionEngine: DetectionEngine? = null
    private var objectTracker: ObjectTracker? = null
    private var trajectoryPredictor: TrajectoryPredictor? = null
    private var decisionEngine: DecisionEngine? = null
    private var gestureController: GestureController? = null
    private var adaptiveScaler: AdaptiveScaler? = null
    private var overlayManager: OverlayManager? = null

    // Processing
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    @Volatile private var isProcessing = false
    @Volatile private var isPaused = false
    @Volatile private var isKilled = false
    private var lastObjectsHash = 0
    private var pauseCounter = 0
    private var frameCount = 0

    // RAM monitoring
    private val ramMonitorHandler = Handler(Looper.getMainLooper())
    private var ramMonitorRunnable: Runnable? = null

    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "Service onCreate")

        // FIX #16: Install global crash handler
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            Log.e(TAG, "CRASH in thread ${t.name}: ${e.message}", e)
            emergencyShutdown("Crash: ${e.message}")
        }

        // Get screen dimensions
        val displayMetrics = DisplayMetrics()
        val windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getMetrics(displayMetrics)
        screenWidth = displayMetrics.widthPixels
        screenHeight = displayMetrics.heightPixels
        densityDpi = displayMetrics.densityDpi  // FIX #3

        Log.d(TAG, "Screen: ${screenWidth}x${screenHeight}, dpi=$densityDpi")

        // Initialize components
        detectionEngine = DetectionEngine(screenWidth, screenHeight, scanStep = 4)
        objectTracker = ObjectTracker()
        trajectoryPredictor = TrajectoryPredictor(screenWidth, screenHeight)
        decisionEngine = DecisionEngine(screenWidth, screenHeight)
        gestureController = GestureController(this, screenWidth, screenHeight)
        adaptiveScaler = AdaptiveScaler(screenWidth, screenHeight)

        // Start foreground notification
        startForegroundNotification()

        // Start RAM monitor
        startRamMonitor()

        // Show overlay
        overlayManager = OverlayManager(this) { active ->
            isPaused = !active
        }
        overlayManager?.show()
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        Log.d(TAG, "Service connected")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)

        when (intent?.action) {
            "ACTION_START" -> {
                @Suppress("DEPRECATION")
                val data = intent.getParcelableExtra<Intent>("screenCaptureData")
                if (data != null) {
                    startScreenCapture(data)
                }
            }
            "ACTION_STOP" -> {
                stopGameAssist()
            }
        }

        return START_STICKY
    }

    /**
     * Start screen capture.
     * FIX #2: Uses DOWNSCALED resolution to prevent OOM on 4GB phones.
     * FIX #5: No ImageAvailableListener — coroutine-only acquisition.
     */
    private fun startScreenCapture(data: Intent) {
        Log.d(TAG, "Starting screen capture at ${CAPTURE_WIDTH}x${CAPTURE_HEIGHT}")
        val mediaProjectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        try {
            mediaProjection = mediaProjectionManager.getMediaProjection(RESULT_OK, data)
            mediaProjection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    Log.w(TAG, "MediaProjection stopped by system")
                    cleanup()
                }
            }, Handler(Looper.getMainLooper()))

            // FIX #2: Use DOWNSCALED resolution, NOT full screen
            // Full 720x1650 at 4bytes = ~4.7MB per frame → OOM on 4GB
            // Downscaled 360x800 at 4bytes = ~1.1MB per frame → safe
            imageReader = ImageReader.newInstance(
                CAPTURE_WIDTH,
                CAPTURE_HEIGHT,
                PixelFormat.RGBA_8888,
                2  // Minimal buffer for budget phones
            )

            virtualDisplay = mediaProjection?.createVirtualDisplay(
                "GameAssist",
                CAPTURE_WIDTH,
                CAPTURE_HEIGHT,
                densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader?.surface,
                null,
                Handler(Looper.getMainLooper())
            )

            // FIX #5: NO setOnImageAvailableListener.
            // The coroutine loop acquires images directly.

            gestureController?.start()
            startProcessingLoop()

            Log.d(TAG, "Screen capture started at ${CAPTURE_WIDTH}x${CAPTURE_HEIGHT}")

        } catch (e: Exception) {
            Log.e(TAG, "Failed to start screen capture: ${e.message}", e)
            stopSelf()
        }
    }

    /**
     * Main processing loop.
     */
    private fun startProcessingLoop() {
        scope.launch {
            Log.d(TAG, "Processing loop started")
            isProcessing = true

            while (isProcessing && !isPaused && !isKilled) {
                val frameStart = System.currentTimeMillis()

                // Check RAM before processing (FIX #19)
                if (!checkRamSafety()) {
                    emergencyShutdown("Low RAM - auto shutdown for phone safety")
                    break
                }

                // Check if frame should be skipped (thermal throttling)
                if (adaptiveScaler?.shouldSkipFrame() == true) {
                    delay(adaptiveScaler?.getFrameIntervalMs() ?: 83L)
                    continue
                }

                try {
                    processCurrentFrame()
                } catch (e: OutOfMemoryError) {
                    Log.e(TAG, "OOM during frame processing! Emergency shutdown.")
                    emergencyShutdown("Out of Memory")
                    break
                } catch (e: Exception) {
                    Log.e(TAG, "Frame processing error: ${e.message}")
                }

                val frameTime = System.currentTimeMillis() - frameStart
                adaptiveScaler?.recordFrameTime(frameTime)

                val targetInterval = adaptiveScaler?.getFrameIntervalMs() ?: 83L
                val remainingDelay = targetInterval - frameTime
                if (remainingDelay > 0) {
                    delay(remainingDelay)
                }
            }
        }
    }

    /**
     * Process a single frame.
     */
    private fun processCurrentFrame() {
        val reader = imageReader ?: return
        val detection = detectionEngine ?: return
        val tracker = objectTracker ?: return
        val predictor = trajectoryPredictor ?: return
        val decider = decisionEngine ?: return
        val gesture = gestureController ?: return

        // Acquire image (FIX #5: direct acquisition, no listener)
        val image: Image? = reader.acquireLatestImage()
        if (image == null) return

        try {
            val startTime = System.currentTimeMillis()

            val bitmap = imageToBitmap(image, CAPTURE_WIDTH, CAPTURE_HEIGHT)
            if (bitmap == null) return

            // FIX #13: Now works — scanStep is var in DetectionEngine
            detection.scanStep = adaptiveScaler?.scanStep ?: 4

            val detectedObjects = detection.detectFrame(bitmap)
            bitmap.recycle()  // Immediately free memory

            val timestamp = System.currentTimeMillis()
            val trackedObjects = tracker.updateFrame(detectedObjects, timestamp)

            // Predict UFO trajectories
            val ufoTrajectories = mutableMapOf<Int, Trajectory>()
            for (ufo in tracker.getActiveUFOs()) {
                val history = tracker.getPositionHistory(ufo)
                if (history != null && history.size >= 3) {
                    val trajectory = predictor.predictTrajectory(history)
                    if (trajectory != null) {
                        ufoTrajectories[ufo.id] = trajectory.copy(objectId = ufo.id)
                    }
                }
            }

            // Pause detection
            val currentHash = trackedObjects.hashCode()
            if (currentHash == lastObjectsHash) {
                pauseCounter++
                if (pauseCounter >= 20) {
                    overlayManager?.updateStatus(getString(R.string.status_paused))
                    return
                }
            } else {
                pauseCounter = 0
                lastObjectsHash = currentHash
            }

            // Make movement decision
            val currentFps = adaptiveScaler?.targetFps ?: 12f
            val decision = decider.decide(trackedObjects, ufoTrajectories, currentFps)

            // Execute movement
            gesture.moveTo(decision.targetX, decision.urgencyMs)

            // Update overlay
            val statusText = when {
                decision.isCollecting -> "${getString(R.string.status_collecting)} X:${decision.targetX}"
                decision.priority == com.gameassist.models.ThreatPriority.CRITICAL ->
                    "DODGE X:${decision.targetX}"
                decision.priority == com.gameassist.models.ThreatPriority.HIGH ->
                    "AVOID X:${decision.targetX}"
                else -> "OK X:${decision.targetX}"
            }
            overlayManager?.updateStatus(statusText)

            frameCount++

        } finally {
            image.close()  // ALWAYS close image to prevent buffer leak
        }
    }

    /**
     * Convert Image to Bitmap.
     * Uses CAPTURE_WIDTH (downscaled) — NOT full screen.
     */
    private fun imageToBitmap(image: Image, width: Int, height: Int): Bitmap? {
        val planes = image.planes
        if (planes.isEmpty()) return null

        val buffer: ByteBuffer = planes[0].buffer
        val pixelStride = planes[0].pixelStride
        val rowStride = planes[0].rowStride
        val rowPadding = rowStride - pixelStride * width

        val bitmapWidth = if (rowPadding > 0) width + rowPadding / pixelStride else width

        try {
            val bitmap = Bitmap.createBitmap(bitmapWidth, height, Bitmap.Config.ARGB_8888)
            bitmap.copyPixelsFromBuffer(buffer)

            return if (rowPadding > 0) {
                Bitmap.createBitmap(bitmap, 0, 0, width, height).also {
                    bitmap.recycle()  // Free the padded bitmap immediately
                }
            } else {
                bitmap
            }
        } catch (e: OutOfMemoryError) {
            Log.e(TAG, "OOM creating bitmap!")
            return null
        } catch (e: Exception) {
            Log.e(TAG, "Error creating bitmap: ${e.message}")
            return null
        }
    }

    // ──────────────────────────────────────────────
    // RAM MONITOR (FIX #19) — Protects 4GB phones
    // ──────────────────────────────────────────────

    private fun startRamMonitor() {
        ramMonitorRunnable = object : Runnable {
            override fun run() {
                if (!isKilled) {
                    checkRamSafety()
                    ramMonitorHandler?.postDelayed(this, 5000)  // Check every 5s
                }
            }
        }
        ramMonitorHandler.postDelayed(ramMonitorRunnable!!, 5000)
    }

    /**
     * Check if phone has enough RAM. Auto-shutdown if too low.
     * Returns true if safe to continue.
     */
    private fun checkRamSafety(): Boolean {
        val runtime = Runtime.getRuntime()
        val usedMb = (runtime.totalMemory() - runtime.freeMemory()) / (1024 * 1024)
        val maxMb = runtime.maxMemory() / (1024 * 1024)
        val freeMb = maxMb - usedMb

        if (freeMb < RAM_SHUTDOWN_MB) {
            Log.w(TAG, "RAM CRITICAL: ${freeMb}MB free < ${RAM_SHUTDOWN_MB}MB. AUTO SHUTDOWN.")
            return false
        }

        if (freeMb < RAM_WARNING_MB) {
            Log.w(TAG, "RAM LOW: ${freeMb}MB free. Heavy throttle.")
            adaptiveScaler?.forceThrottle()
        }

        return true
    }

    // ──────────────────────────────────────────────
    // HARDWARE KILL SWITCH (Challenge 4)
    // ──────────────────────────────────────────────

    override fun onKeyEvent(event: android.view.KeyEvent): Boolean {
        if (event.keyCode == android.view.KeyEvent.KEYCODE_VOLUME_DOWN) {
            if (event.action == android.view.KeyEvent.ACTION_DOWN) {
                Log.w(TAG, "VOLUME DOWN - EMERGENCY KILL!")
                emergencyShutdown("Volume Down pressed")
                return true
            }
        }
        return super.onKeyEvent(event)
    }

    private fun emergencyShutdown(reason: String) {
        isKilled = true
        isProcessing = false
        isPaused = true
        gestureController?.emergencyKill()
        stopScreenCapture()
        overlayManager?.updateState(false)
        overlayManager?.updateStatus("STOPPED: $reason")

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("GameAssist STOPPED")
            .setContentText("Reason: $reason. Phone is safe.")
            .setSmallIcon(android.R.drawable.ic_media_pause)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        val manager = getSystemService(android.app.NotificationManager::class.java)
        manager.notify(FOREGROUND_NOTIFY_ID + 1, notification)

        Log.w(TAG, "Emergency shutdown: $reason")
    }

    // ──────────────────────────────────────────────
    // Lifecycle
    // ──────────────────────────────────────────────

    private fun stopGameAssist() {
        Log.d(TAG, "Stopping GameAssist")
        isProcessing = false
        isPaused = true
        isKilled = true

        gestureController?.stop()
        stopScreenCapture()
        stopRamMonitor()
        overlayManager?.hide()

        scope.cancel()
        decisionEngine?.reset()
        objectTracker?.reset()
        adaptiveScaler?.reset()

        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun stopScreenCapture() {
        try { virtualDisplay?.release() } catch (_: Exception) {}
        virtualDisplay = null
        try { imageReader?.close() } catch (_: Exception) {}
        imageReader = null
        try { mediaProjection?.stop() } catch (_: Exception) {}
        mediaProjection = null
    }

    private fun stopRamMonitor() {
        ramMonitorRunnable?.let { ramMonitorHandler.removeCallbacks(it) }
        ramMonitorRunnable = null
    }

    private fun cleanup() {
        isProcessing = false
        gestureController?.stop()
        stopScreenCapture()
        stopRamMonitor()
        overlayManager?.hide()
    }

    /**
     * FIX #14: Foreground service with proper type for Android 14+.
     */
    private fun startForegroundNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = android.app.NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                android.app.NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(android.app.NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(getString(R.string.notification_text))
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .build()

        // FIX #14: Specify foregroundServiceType for Android 14+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                FOREGROUND_NOTIFY_ID,
                notification,
                Service.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(FOREGROUND_NOTIFY_ID, notification)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Not needed - screen capture based
    }

    override fun onInterrupt() {
        Log.w(TAG, "Service interrupted")
        emergencyShutdown("AccessibilityService interrupted")
    }

    override fun onDestroy() {
        super.onDestroy()
        cleanup()
        scope.cancel()
    }
}
